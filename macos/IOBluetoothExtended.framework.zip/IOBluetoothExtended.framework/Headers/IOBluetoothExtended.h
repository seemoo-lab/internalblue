//
//  IOBluetoothExtended.h
//  IOBluetoothExtended
//
//  Created by Davide Toldo on 06.07.19.
//  Copyright © 2019 Davide Toldo. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <HCIDelegate.h>
#import <HCICommunicator.h>
#import <IOBluetoothHostController.h>

//! Project version number for IOBluetoothExtended.
FOUNDATION_EXPORT double IOBluetoothExtendedVersionNumber;

//! Project version string for IOBluetoothExtended.
FOUNDATION_EXPORT const unsigned char IOBluetoothExtendedVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <IOBluetoothExtended/PublicHeader.h>
